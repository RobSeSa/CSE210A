My code is run using the make command. This will create a ./while executable. There is a custom.bats file that includes my 5 extra test cases.
