Robert Sato
rssato
1517254
CSE 210A - Programming Languages
Prof. Cormac Flanagan

HW4 - WHILE-SS

Requirements:
- python 3
- collections - for sorted dictionary used as store

Running program
- add the line "export PATH=$PATH:$PWD/libexec/bats-core" to the test.sh file
- ./test.sh will then call make which creates an executable while-ss used for testing

References:
- WHILE slides in class
- https://ruslanspivak.com/lsbasi-part7/
	- parser implementation as noted in code
