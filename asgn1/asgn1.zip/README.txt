Robert Sato
Prof. Cormac A Flanagan 
CSE 210A
Jan 15, 2021

HW1: ARITH

Requirements:
- add this to the test.sh script: export PATH=$PATH:$PWD/libexec/bats-core
- python3

To run:
make - creates an executable ./arith from asgn1.python3

Files:
ARITH.ipynb - implementation of this assignment with test cases along the way
asgn1.py - ARITH.ipynb converted to .py and cleaned up
Makefile
REPORT.pdf - report with screen shots of testing